<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="../style.css">
    <title>SocialFiles</title>
</head>

    <body>
        
    
        <br>
        <h1 align=center>Social<i>Files</i></h1>
		
        <main>
        <form align=center action="files.php" method="post" enctype="multipart/form-data">
          <input type="file" name="fileToUpload" id="fileToUpload">
          <input type="submit" value="Upload file" name="submit">
        </form>
        </main>
		
		<p align=center>or</p>
		
		<main style="max-width: 600px;">
			<h1 align="left">/uploads</h1>
		</main>
		
		<main style="text-align: left; border-style: solid; border-width: 1px; max-width: 600px; padding: 12px;">
		
		<?php

		// function to get the file extension (type)
		function ext( $file ) {
			if ( is_dir( $file ) ) {
				return 'dir';
			} else {
				return str_replace( '7z', 'sevenz', strtolower( pathinfo( $file )['extension'] ) );
			}
		}

		// function to get the title, from the url
		function title() {
			$url = substr( $_SERVER['REQUEST_URI'], 1 );
			if ( empty( $url ) ) $url = 'uploads/';
			return $url;
		}

		// function to get human-readable filesize
		function human_filesize( $file ) {
			$bytes = filesize( $file );
			$decimals = 1;
			$factor = floor( ( strlen($bytes) - 1 ) / 3 );
			if ( $factor > 0 ) $sz = 'KMGT';
			return sprintf( "%.{$decimals}f", $bytes / pow( 1024, $factor ) ) . @$sz[$factor - 1] . 'B';
		}

		// get the file list for the current directory
		$files = scandir( '.' );

		// files to exclude from the files array.
		$exclude = array( '.', '..', '.DS_Store', 'index.php', '.git', '.gitmodules', '.gitignore', 'node_modules' );

		// search files array and remove anything in the exclude array
		foreach ( $exclude as $ex ) {
			if ( ( $key = array_search( $ex, $files ) ) !== false ) {
				unset( $files[$key] );
			}
		}

		// title bar and tiny stylesheet with all the icons encoded in it.
		?><head><title><?php print str_replace( '/', ' / ', title() ); ?></title><meta name="viewport" content="width=device-width"></head><div class="container"><?php

		// display a title on the top of the listing
		

		// if the array of files isn't empty
		if ( !empty( $files ) ) {

			// open unordered list tag
			print "<ul>";

			// loop through the files array
			foreach ( $files as $file ) {

				// show the file
				print '<a href="./' . $file . '"><li class="' . ext( $file ) . '">' . $file . ( !is_dir( $file ) ? ' <span>' . human_filesize( $file ) . '</span>' : '' ) . '</li></a>';

			}

			// close unordered list tag
			print "</ul>";

		} else {

			// display empty directory message
			print "<p>This folder contains no files.</p>";

		}

?></div>
		</main>
    </body>
    
</html>
