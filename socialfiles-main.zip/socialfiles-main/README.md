This is my file sharing website im building it uses PHP and basic html and css.

You can use wamp or xampp to host this website. It should work fine to upload but im still working
on getting downloads available and searches.
